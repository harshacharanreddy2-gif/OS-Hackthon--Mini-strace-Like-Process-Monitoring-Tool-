import express from 'express';
import cors from 'cors';
import { spawn } from 'node:child_process';
import { mkdtemp, readFile, rm, access } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');
const DEMOS = path.join(ROOT, 'demos');
const PORT = Number(process.env.PORT || 4000);
const app = express();
app.use(cors({ origin: ['http://localhost:5173', 'http://127.0.0.1:5173'] }));
app.use(express.json({ limit: '10kb' }));

const PRESETS = {
  file_io: { label: 'File I/O', description: 'Open, write, read, and close a small temporary file.', executable: path.join(DEMOS, 'file_io'), category: 'Files' },
  process_demo: { label: 'Process lifecycle', description: 'Observe process creation and child-process completion.', executable: path.join(DEMOS, 'process_demo'), category: 'Processes' },
  memory_demo: { label: 'Memory allocation', description: 'Observe memory mapping and allocation-related calls.', executable: path.join(DEMOS, 'memory_demo'), category: 'Memory' },
  pipe_demo: { label: 'Pipe communication', description: 'Send a short message between related processes using a pipe.', executable: path.join(DEMOS, 'pipe_demo'), category: 'IPC' }
};
const allowedSyscalls = new Set(['execve','execveat','clone','clone3','fork','vfork','wait4','waitid','exit','exit_group','open','openat','openat2','creat','read','write','readv','writev','close','lseek','stat','newfstatat','fstat','access','faccessat','mmap','munmap','mprotect','brk','mremap','pipe','pipe2','dup','dup2','dup3','fcntl','rt_sigaction','rt_sigprocmask','rt_sigreturn','getpid','getppid','gettid','arch_prctl','set_tid_address','set_robust_list','prlimit64','rseq','uname','getrandom','futex','clock_nanosleep','nanosleep']);

function runChild(command, args, options = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { ...options, stdio: ['ignore', 'pipe', 'pipe'], env: { PATH: process.env.PATH || '/usr/bin:/bin', LANG: 'C', LC_ALL: 'C' } });
    let stdout = '', stderr = '';
    const max = 150_000;
    child.stdout.on('data', d => { if (stdout.length < max) stdout += d.toString().slice(0, max - stdout.length); });
    child.stderr.on('data', d => { if (stderr.length < max) stderr += d.toString().slice(0, max - stderr.length); });
    const timer = setTimeout(() => { child.kill('SIGKILL'); reject(new Error('Demo exceeded the 5-second safety limit.')); }, 5000);
    child.on('error', err => { clearTimeout(timer); reject(err); });
    child.on('close', (code, signal) => { clearTimeout(timer); resolve({ code, signal, stdout, stderr }); });
  });
}

app.get('/api/health', (_req, res) => res.json({ ok: true, platform: process.platform, tracingAvailable: process.platform === 'linux' }));
app.get('/api/presets', (_req, res) => res.json({ presets: Object.entries(PRESETS).map(([id, p]) => ({ id, label: p.label, description: p.description, category: p.category })) }));

app.post('/api/trace', async (req, res) => {
  const id = req.body?.preset;
  const preset = PRESETS[id];
  if (!preset) return res.status(400).json({ error: 'Choose one of the provided demo programs.' });
  if (process.platform !== 'linux') return res.status(501).json({ error: 'Real tracing requires Linux. Run this project in Ubuntu or WSL2 with strace installed.' });
  let tempDir;
  try {
    await access(preset.executable);
    tempDir = await mkdtemp(path.join(tmpdir(), 'mini-strace-'));
    const traceFile = path.join(tempDir, 'trace.log');
    // The executable and arguments are selected exclusively from this server-side allowlist.
    const trace = await runChild('strace', ['-f', '-tt', '-T', '-s', '120', '-e', 'trace=%process,%file,%memory,%desc', '-o', traceFile, preset.executable], { cwd: tempDir });
    let raw = '';
    try { raw = await readFile(traceFile, 'utf8'); } catch { /* strace may fail before creating its output file */ }
    const events = raw.split('\n').filter(Boolean).slice(0, 1500).map((line, index) => {
      const pidMatch = line.match(/^\s*(\d+)\s+/);
      const timeMatch = line.match(/\b(\d{2}:\d{2}:\d{2}\.\d+)\s+/);
      const callMatch = line.match(/(?:^|\s)([a-zA-Z_][a-zA-Z0-9_]*)\((.*)/);
      const name = callMatch?.[1] || (line.includes('+++') ? 'process_event' : 'unknown');
      const resultMatch = line.match(/\)\s+=\s+(.+)$/);
      const result = resultMatch?.[1] || (line.includes('+++') ? line.slice(line.indexOf('+++')) : '');
      const failed = /\s= -1 \w+ \(/.test(line) || /\s= -1 \w+$/.test(line);
      return { id: index + 1, pid: pidMatch?.[1] || '—', time: timeMatch?.[1] || '—', syscall: name, result: result.slice(0, 160), status: failed ? 'error' : 'ok', raw: line.slice(0, 500) };
    });
    const counts = {};
    for (const event of events) counts[event.syscall] = (counts[event.syscall] || 0) + 1;
    const topCalls = Object.entries(counts).sort((a,b) => b[1] - a[1]).slice(0, 8).map(([name,count]) => ({ name,count }));
    res.json({ preset: id, label: preset.label, events, topCalls, total: events.length, failures: events.filter(e => e.status === 'error').length, exitCode: trace.code, stdout: trace.stdout.trim(), stderr: trace.stderr.trim(), capturedAt: new Date().toISOString(), truncated: raw.split('\n').length > 1500 });
  } catch (error) {
    const message = error.code === 'ENOENT' ? 'strace was not found. Install it with: sudo apt update && sudo apt install strace' : error.message;
    res.status(500).json({ error: message });
  } finally {
    if (tempDir) await rm(tempDir, { recursive: true, force: true }).catch(() => {});
  }
});

app.listen(PORT, '127.0.0.1', () => console.log(`Mini strace API running at http://127.0.0.1:${PORT}`));
