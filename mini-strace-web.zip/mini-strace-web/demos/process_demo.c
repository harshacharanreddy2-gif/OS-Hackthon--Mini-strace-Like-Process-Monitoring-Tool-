#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

int main(void) {
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }
    if (pid == 0) {
        printf("Child process: PID=%ld, PPID=%ld\n", (long)getpid(), (long)getppid());
        _exit(0);
    }
    int status = 0;
    printf("Parent process: PID=%ld, child PID=%ld\n", (long)getpid(), (long)pid);
    if (waitpid(pid, &status, 0) < 0) { perror("waitpid"); return 1; }
    printf("Parent observed child termination.\n");
    return 0;
}
