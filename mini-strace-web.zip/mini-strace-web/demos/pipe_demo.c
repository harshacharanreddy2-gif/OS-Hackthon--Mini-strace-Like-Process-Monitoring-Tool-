#include <stdio.h>
#include <string.h>
#include <sys/wait.h>
#include <unistd.h>

int main(void) {
    int fds[2];
    if (pipe(fds) < 0) { perror("pipe"); return 1; }
    pid_t pid = fork();
    if (pid < 0) { perror("fork"); return 1; }
    if (pid == 0) {
        close(fds[1]);
        char buffer[100] = {0};
        ssize_t n = read(fds[0], buffer, sizeof(buffer) - 1);
        if (n > 0) { buffer[n] = '\0'; printf("Child received: %s\n", buffer); }
        close(fds[0]);
        _exit(0);
    }
    close(fds[0]);
    const char *message = "Hello through an anonymous pipe";
    if (write(fds[1], message, strlen(message)) < 0) perror("write");
    close(fds[1]);
    waitpid(pid, NULL, 0);
    puts("Pipe communication complete.");
    return 0;
}
