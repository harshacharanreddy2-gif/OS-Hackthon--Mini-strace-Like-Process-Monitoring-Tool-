#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void) {
    size_t size = 4096;
    char *memory = malloc(size);
    if (!memory) { perror("malloc"); return 1; }
    memset(memory, 'A', size);
    memory[size - 1] = '\0';
    printf("Allocated %zu bytes and initialized the buffer. First byte: %c\n", size, memory[0]);
    free(memory);
    puts("Memory released.");
    return 0;
}
