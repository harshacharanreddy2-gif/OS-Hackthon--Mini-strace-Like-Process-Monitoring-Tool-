#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main(void) {
    char buffer[128] = {0};
    const char *message = "Mini strace demo: file I/O works!\n";
    int fd = open("trace_demo.txt", O_CREAT | O_TRUNC | O_RDWR, 0600);
    if (fd < 0) { perror("open"); return 1; }
    if (write(fd, message, strlen(message)) < 0) { perror("write"); close(fd); return 1; }
    if (lseek(fd, 0, SEEK_SET) < 0) { perror("lseek"); close(fd); return 1; }
    ssize_t n = read(fd, buffer, sizeof(buffer) - 1);
    if (n < 0) { perror("read"); close(fd); return 1; }
    buffer[n] = '\0';
    printf("Read back: %s", buffer);
    close(fd);
    return 0;
}
