# TraceLab — Mini strace-Like Process Monitoring Tool

An educational web application for a Linux/Operating Systems hackathon. It runs a small set of **predefined, harmless C demonstrations** under `strace`, then visualizes the captured system calls in a dashboard.

## Features

- Four safe demo presets: File I/O, Process Lifecycle, Memory Allocation, and Anonymous Pipe IPC.
- Real Linux syscall capture through `strace` (not just mocked data) when run on Linux/Ubuntu/WSL2.
- Dashboard with event totals, failed calls, frequent calls, searchable/filterable trace table, and a syscall inspector.
- Export filtered events to CSV and the visible trace to TXT.
- Backend allowlists demo IDs; it does not accept arbitrary shell commands or user-provided executable paths. Each trace is limited to 5 seconds and runs with the privileges of the user who started the server.
- If the API is not connected, the frontend displays a sample preview so the dashboard can still be explored.

## Requirements

- Ubuntu Linux or WSL2 with Ubuntu (real tracing is Linux-only)
- Node.js 20 or newer and npm
- GCC and `strace`

Install system dependencies on Ubuntu:

```bash
sudo apt update
sudo apt install -y nodejs npm gcc strace
```

Check:

```bash
node --version
npm --version
gcc --version
strace -V
```

## Run locally

Open a terminal in the project folder:

```bash
npm install
npm run install:all
npm run build:demos
npm run dev
```

Open **http://127.0.0.1:5173** in your browser. The API runs at **http://127.0.0.1:4000**.

If `node` is not Node.js 20+, install a current LTS release before running the commands. On Windows, use Ubuntu in WSL2 rather than running `strace` directly in PowerShell. Keep both frontend and API bound to localhost for the classroom demo.

## Production build

```bash
npm run build
npm start
```

The production build creates `client/dist`. The API remains a separate local process; use the Vite dev server for the simplest hackathon demonstration, or configure a local static-file server for production hosting.

## How it works

1. The React/Vite frontend requests the fixed list of allowed demo programs from the Express API.
2. When you press **Run trace**, the browser sends only a preset ID, for example `file_io`.
3. The server maps that ID to a compiled C executable and launches `strace` with a syscall filter for process, file, memory, and descriptor activity.
4. The backend parses the trace log and returns normalized events and call counts.
5. The dashboard renders the result and can export CSV/TXT files.

## Demo presets and course outcomes

| Preset | Concepts demonstrated | Syllabus links |
|---|---|---|
| File I/O | `openat`, `read`, `write`, `lseek`, `close` | CO-1, CO-5 |
| Process lifecycle | `clone`/`fork`, `wait4`, `exit_group` | CO-1, CO-2 |
| Memory allocation | `brk`, `mmap`, `munmap` (implementation-dependent) | CO-4 |
| Anonymous pipe | `pipe`, `read`, `write`, process creation and wait | CO-2, CO-3 |

**Important:** observed system calls depend on the Linux version, C library, compiler and runtime. The dashboard should be used to explain actual captured output, not to claim every call is guaranteed on every machine.

## Project structure

```text
mini-strace-web/
├── client/
│   ├── index.html
│   ├── vite.config.js
│   └── src/
│       ├── main.jsx
│       └── style.css
├── server/
│   ├── index.js
│   └── package.json
├── demos/
│   ├── file_io.c
│   ├── process_demo.c
│   ├── memory_demo.c
│   └── pipe_demo.c
├── package.json
└── README.md
```

## Troubleshooting

- **`strace` was not found:** `sudo apt install strace`.
- **Demo executable missing:** run `npm run build:demos` from the project root.
- **Port 4000 or 5173 already in use:** stop the other local process or change `PORT` for the API / Vite port in `client/vite.config.js`.
- **Real tracing unavailable on Windows:** run the project inside Ubuntu on WSL2; the browser can remain on Windows and open the local URL.
- **Permission errors in a trace:** explain them as kernel-returned errors (for example, `EACCES` or `ENOENT`). Do not run the app with `sudo` just to hide them.

## Safety notes

This is a teaching prototype, not a production process supervisor. It intentionally accepts no arbitrary commands, does not trace unrelated processes, and binds the API to `127.0.0.1`. Run only on a computer you are authorized to use. Do not expose the API to a public network. The trace is temporary and is removed after the API responds; use the dashboard's export buttons if you need a copy.

## Team demo flow (about 3 minutes)

1. Introduce the user-space dashboard and Linux tracing backend.
2. Select **File I/O** and click **Run trace**.
3. Point out `openat`, `write`, `lseek`, `read`, and `close`; click a row to explain it.
4. Export CSV and show the report.
5. Run **Process lifecycle** and compare parent/child process calls.
6. Explain that `strace` observes the boundary between user programs and kernel services; it does not modify the kernel.

## GitHub checklist

- [ ] Create a repository and add these source files.
- [ ] Include this README and the project report / PPT.
- [ ] Add screenshots of the dashboard and one real trace.
- [ ] Include test cases for each of the four presets.
- [ ] Do not commit `node_modules`, compiled demo binaries, or trace output.
