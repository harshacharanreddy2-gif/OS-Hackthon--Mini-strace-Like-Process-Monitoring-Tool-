import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { Activity, ArrowDownToLine, ArrowUpRight, CheckCircle2, ChevronDown, CircleHelp, Clock3, Command, Cpu, FileSearch, Files, Gauge, Layers3, MemoryStick, Play, RefreshCw, Search, ShieldCheck, Terminal, Workflow, XCircle } from 'lucide-react';
import './style.css';

const API = 'http://127.0.0.1:4000/api';
const pretty = (value) => new Intl.NumberFormat().format(value || 0);
const demoFallback = [
  { id: 1, pid: '2410', time: '10:22:01.120441', syscall: 'execve', result: '0', status: 'ok', raw: 'execve("./file_io", ["./file_io"], 0x7fff...) = 0' },
  { id: 2, pid: '2410', time: '10:22:01.120813', syscall: 'openat', result: '3', status: 'ok', raw: 'openat(AT_FDCWD, "trace_demo.txt", O_RDWR|O_CREAT|O_TRUNC, 0600) = 3' },
  { id: 3, pid: '2410', time: '10:22:01.121002', syscall: 'write', result: '34', status: 'ok', raw: 'write(3, "Mini strace demo: file I/O works!\\n", 34) = 34' },
  { id: 4, pid: '2410', time: '10:22:01.121227', syscall: 'lseek', result: '0', status: 'ok', raw: 'lseek(3, 0, SEEK_SET) = 0' },
  { id: 5, pid: '2410', time: '10:22:01.121390', syscall: 'read', result: '34', status: 'ok', raw: 'read(3, "Mini strace demo: file I/O works!\\n", 127) = 34' },
  { id: 6, pid: '2410', time: '10:22:01.121641', syscall: 'close', result: '0', status: 'ok', raw: 'close(3) = 0' },
  { id: 7, pid: '2410', time: '10:22:01.121799', syscall: 'exit_group', result: '?', status: 'ok', raw: 'exit_group(0) = ?' }
];
const syscallInfo = {
  execve: ['Process', 'Replaces the current process image with a new program.'], execveat: ['Process', 'Executes a program relative to a directory descriptor.'],
  openat: ['File I/O', 'Opens a file relative to a directory descriptor.'], open: ['File I/O', 'Opens a file and returns a file descriptor.'], read: ['File I/O', 'Copies bytes from a file descriptor into memory.'], write: ['File I/O', 'Copies bytes from memory to a file descriptor.'], close: ['File I/O', 'Releases a file descriptor.'], lseek: ['File I/O', 'Changes the current offset of an open file.'],
  clone: ['Process', 'Creates a child task; commonly used by process and thread creation.'], fork: ['Process', 'Creates a child process.'], wait4: ['Process', 'Waits for a child process state change.'], exit_group: ['Process', 'Terminates all threads in the process.'], exit: ['Process', 'Terminates the calling thread.'],
  mmap: ['Memory', 'Maps memory into the process address space.'], munmap: ['Memory', 'Removes a memory mapping.'], brk: ['Memory', 'Changes the process data-segment end.'], mprotect: ['Memory', 'Changes memory-page access permissions.'], pipe: ['IPC', 'Creates a unidirectional communication channel.'], pipe2: ['IPC', 'Creates a pipe with configurable flags.'], futex: ['Concurrency', 'Provides a low-level primitive used for synchronization.']
};
const presetMeta = {
  file_io: { icon: Files, title: 'File I/O', subtitle: 'Open, write, read and close a temporary file', color: 'blue', detail: 'Great for CO-5: file descriptors and Linux file I/O.' },
  process_demo: { icon: Workflow, title: 'Process lifecycle', subtitle: 'Create a child and wait for it to finish', color: 'purple', detail: 'Great for CO-2: fork, parent/child execution and wait.' },
  memory_demo: { icon: MemoryStick, title: 'Memory allocation', subtitle: 'Allocate, initialize and release a buffer', color: 'green', detail: 'Great for CO-4: memory allocation and process address space.' },
  pipe_demo: { icon: Activity, title: 'Pipe communication', subtitle: 'Send a message between related processes', color: 'orange', detail: 'Great for CO-3: IPC, pipes, read/write and process control.' }
};
function App() {
  const [presets, setPresets] = useState([]);
  const [selected, setSelected] = useState('file_io');
  const [trace, setTrace] = useState({ events: demoFallback, total: demoFallback.length, failures: 0, topCalls: [['openat', 1], ['read', 1], ['write', 1], ['close', 1], ['execve', 1], ['lseek', 1], ['exit_group', 1]].map(([name,count]) => ({ name,count })), stdout: 'Demo preview — run a trace on Linux to capture real system calls.', capturedAt: null, demo: true });
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('All calls');
  const [running, setRunning] = useState(false);
  const [notice, setNotice] = useState('Preview mode: connect the Linux backend to capture real calls.');
  const [backendOnline, setBackendOnline] = useState(false);
  const [detail, setDetail] = useState(null);
  const [showAll, setShowAll] = useState(false);
  useEffect(() => {
    fetch(`${API}/health`).then(r => r.json()).then(d => { setBackendOnline(d.ok && d.platform === 'linux'); if (d.platform !== 'linux') setNotice('Backend is reachable, but real tracing requires Linux / Ubuntu / WSL2.'); else setNotice('Linux tracing backend connected. Select a demo and press Run trace.'); }).catch(() => {});
    fetch(`${API}/presets`).then(r => r.json()).then(d => setPresets(d.presets || [])).catch(() => {});
  }, []);
  const events = trace.events || [];
  const filtered = useMemo(() => events.filter(e => {
    const text = `${e.syscall} ${e.pid} ${e.result} ${e.raw}`.toLowerCase();
    const matchesQuery = text.includes(query.toLowerCase());
    const matchesFilter = filter === 'All calls' || (filter === 'Errors only' ? e.status === 'error' : (syscallInfo[e.syscall]?.[0] || 'Other') === filter);
    return matchesQuery && matchesFilter;
  }), [events, query, filter]);
  const calls = trace.topCalls || [];
  const maxCall = Math.max(1, ...calls.map(c => c.count));
  async function runTrace() {
    setRunning(true); setNotice('Starting the selected test program…'); setDetail(null);
    try {
      const response = await fetch(`${API}/trace`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ preset: selected }) });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Trace failed');
      setTrace({ ...data, demo: false }); setNotice(`Trace completed: ${data.total} events captured from ${presetMeta[selected].title}.`);
    } catch (error) {
      setNotice(error.message); setBackendOnline(false);
    } finally { setRunning(false); }
  }
  function downloadCsv() {
    const rows = [['id','pid','time','syscall','result','status','raw'], ...filtered.map(e => [e.id,e.pid,e.time,e.syscall,e.result,e.status,e.raw])];
    const csv = rows.map(row => row.map(v => `"${String(v ?? '').replaceAll('"','""')}"`).join(',')).join('\r\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
    const a = document.createElement('a'); a.href = url; a.download = 'mini-strace-report.csv'; a.click(); URL.revokeObjectURL(url);
  }
  function downloadTrace() {
    const text = events.map(e => e.raw).join('\n');
    const url = URL.createObjectURL(new Blob([text], { type: 'text/plain;charset=utf-8;' }));
    const a = document.createElement('a'); a.href = url; a.download = 'mini-strace-trace.txt'; a.click(); URL.revokeObjectURL(url);
  }
  const selectedMeta = presetMeta[selected] || presetMeta.file_io;
  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark"><Command size={22}/></div><div><strong>Trace<span>Lab</span></strong><small>LINUX OBSERVABILITY</small></div></div>
      <div className="nav-label">WORKSPACE</div>
      <button className="nav-item active"><Activity size={17}/> System call monitor <span className="nav-dot"/></button>
      <button className="nav-item" onClick={() => setNotice('Choose a preset card to inspect process, memory, file I/O or IPC behavior.')}><Layers3 size={17}/> Demo library</button>
      <button className="nav-item" onClick={() => setNotice('This educational tool uses strace and a fixed allowlist of safe demo programs.')}><ShieldCheck size={17}/> Safety & scope</button>
      <div className="sidebar-bottom"><div className="kernel-card"><div className="kernel-icon"><Terminal size={17}/></div><div><strong>Kernel observer</strong><small>{backendOnline ? 'Linux backend connected' : 'Waiting for Linux backend'}</small></div><span className={backendOnline ? 'status-dot online' : 'status-dot'}/></div><div className="version">MINI STRACE-LIKE TOOL <span>v1.0.0</span></div></div>
    </aside>
    <main className="main-content">
      <header className="topbar"><div className="breadcrumb">Workspace <span>/</span> <b>System call monitor</b></div><div className="topbar-right"><div className={`connection ${backendOnline ? 'connected' : ''}`}><span className="status-dot"/>{backendOnline ? 'Linux backend online' : 'Preview / offline'}</div><div className="avatar">HC</div></div></header>
      <div className="page-wrap">
        <section className="page-heading"><div><div className="eyebrow"><span className="eyebrow-line"/> OPERATING SYSTEMS LAB</div><h1>System call <span>monitor</span></h1><p>See what your program asks the Linux kernel to do — one system call at a time.</p></div><button className="secondary-btn" onClick={() => { setQuery(''); setFilter('All calls'); setSelected('file_io'); setTrace({ events: demoFallback, total: demoFallback.length, failures: 0, topCalls: [['openat',1],['read',1],['write',1],['close',1],['execve',1],['lseek',1],['exit_group',1]].map(([name,count])=>({name,count})), stdout:'Demo preview — run a trace on Linux to capture real system calls.', demo:true }); setNotice('Preview restored. Run a trace on Linux to capture real calls.'); }}><RefreshCw size={15}/> Reset view</button></section>
        <section className="notice"><div className="notice-icon"><CircleHelp size={17}/></div><div><strong>{trace.demo ? 'Sample trace preview' : 'Live trace result'}</strong><p>{notice}</p></div><button aria-label="Dismiss notice" onClick={() => setNotice('')}><XCircle size={17}/></button></section>
        <section className="section-block"><div className="section-heading"><div><h2>Choose a test program</h2><p>Each preset demonstrates a different operating-system concept.</p></div><span className="tiny-tag"><ShieldCheck size={13}/> PRE-APPROVED DEMOS</span></div>
          <div className="preset-grid">{Object.entries(presetMeta).map(([id, meta]) => { const Icon = meta.icon; return <button key={id} className={`preset-card ${selected === id ? 'selected' : ''}`} onClick={() => setSelected(id)}><div className={`preset-icon ${meta.color}`}><Icon size={20}/></div><div className="preset-copy"><strong>{meta.title}</strong><span>{meta.subtitle}</span></div><div className="radio-mark">{selected === id && <span/>}</div><div className="preset-detail">{meta.detail}</div></button>; })}</div>
          <div className="run-row"><div className="selected-program"><span className="program-pulse"/><div><small>SELECTED PROGRAM</small><strong>{selectedMeta.title}</strong></div><ChevronDown size={15}/></div><button className="run-btn" onClick={runTrace} disabled={running}><Play size={16} fill="currentColor"/>{running ? 'Tracing…' : 'Run trace'} <span>⌘ ↵</span></button></div>
        </section>
        <section className="stats-grid"><div className="stat-card"><div className="stat-top"><span>Total system calls</span><div className="stat-icon blue"><Activity size={17}/></div></div><div className="stat-number">{pretty(trace.total)}<span className="stat-suffix"> calls</span></div><div className="stat-foot"><span className="mini-line"/> Captured events</div></div><div className="stat-card"><div className="stat-top"><span>Successful calls</span><div className="stat-icon green"><CheckCircle2 size={17}/></div></div><div className="stat-number">{pretty(Math.max(0, (trace.total || 0) - (trace.failures || 0)))}</div><div className="stat-foot good">Completed without syscall errors</div></div><div className="stat-card"><div className="stat-top"><span>Failed calls</span><div className="stat-icon red"><XCircle size={17}/></div></div><div className="stat-number">{pretty(trace.failures || 0)}</div><div className="stat-foot">Permission or resource errors</div></div><div className="stat-card"><div className="stat-top"><span>Capture status</span><div className="stat-icon purple"><Clock3 size={17}/></div></div><div className="stat-number status-number"><span className={`status-dot ${trace.demo ? '' : 'online'}`}/>{trace.demo ? 'Preview' : 'Complete'}</div><div className="stat-foot">{trace.capturedAt ? new Date(trace.capturedAt).toLocaleTimeString() : 'No live capture yet'}</div></div></section>
        <section className="analysis-grid"><div className="panel syscall-panel"><div className="panel-header"><div><h2>Most frequent calls</h2><p>Top system calls in this capture</p></div><span className="panel-chip">TOP {Math.min(8,calls.length)}</span></div><div className="call-bars">{calls.length ? calls.slice(0,7).map(c => <div className="bar-row" key={c.name}><span className="bar-name">{c.name}</span><div className="bar-track"><div className="bar-fill" style={{width:`${Math.max(4,c.count/maxCall*100)}%`}}/></div><span className="bar-count">{c.count}</span></div>) : <div className="empty-small">Run a trace to see call frequency.</div>}</div><div className="panel-footer"><span className="legend-dot"/> Calls observed in the trace <span className="footer-spacer"/><button className="text-btn" onClick={() => setFilter('All calls')}>View all calls <ArrowUpRight size={13}/></button></div></div>
          <div className="panel explain-panel"><div className="panel-header"><div><h2>Call inspector</h2><p>Understand the selected event</p></div><div className="inspector-icon"><FileSearch size={17}/></div></div>{detail ? <><div className="inspector-name"><span className="call-pill">{detail.syscall}</span><span className="category-pill">{(syscallInfo[detail.syscall] || ['Other'])[0]}</span></div><p className="inspector-description">{(syscallInfo[detail.syscall] || ['Other','A Linux kernel interface used by this process.'])[1]}</p><div className="inspector-meta"><div><span>PID</span><strong>{detail.pid}</strong></div><div><span>Result</span><strong>{detail.result || '—'}</strong></div></div><div className="raw-box"><small>RAW TRACE LINE</small><code>{detail.raw}</code></div></> : <div className="inspector-empty"><div className="inspect-graphic"><Search size={22}/></div><strong>Select a system call</strong><span>Click any row in the event table to see what it does and how to explain it.</span></div>}</div></section>
        <section className="panel events-panel"><div className="panel-header events-header"><div><h2>System call events</h2><p>Search, filter and inspect captured kernel interactions.</p></div><div className="export-actions"><button className="secondary-btn compact" onClick={downloadTrace}><ArrowDownToLine size={14}/> Trace .txt</button><button className="secondary-btn compact" onClick={downloadCsv}><ArrowDownToLine size={14}/> Export CSV</button></div></div><div className="table-toolbar"><label className="search-box"><Search size={15}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Search syscall, PID, result…"/><kbd>⌘ K</kbd></label><div className="filter-wrap"><span>Filter:</span><select value={filter} onChange={e => setFilter(e.target.value)}><option>All calls</option><option>Process</option><option>File I/O</option><option>Memory</option><option>IPC</option><option>Concurrency</option><option>Errors only</option></select></div></div><div className="table-scroll"><table><thead><tr><th>EVENT</th><th>PID</th><th>TIMESTAMP</th><th>SYSTEM CALL</th><th>RETURN VALUE</th><th>STATUS</th></tr></thead><tbody>{filtered.slice(0, showAll ? 500 : 8).map(e => <tr key={`${e.id}-${e.raw}`} className={detail?.id === e.id ? 'row-selected' : ''} onClick={() => setDetail(e)}><td className="event-id">#{String(e.id).padStart(3,'0')}</td><td className="pid-cell">{e.pid}</td><td className="time-cell">{e.time}</td><td><button className="syscall-link" onClick={ev => {ev.stopPropagation(); setDetail(e);}}>{e.syscall}</button></td><td className="return-cell">{e.result || '—'}</td><td><span className={`result-status ${e.status === 'error' ? 'failed' : 'success'}`}><span/>{e.status === 'error' ? 'Failed' : 'Success'}</span></td></tr>)}</tbody></table>{filtered.length === 0 && <div className="empty-table">No events match your search or filter.</div>}</div><div className="table-bottom"><span>Showing <b>{Math.min(filtered.length, showAll ? 500 : 8)}</b> of <b>{filtered.length}</b> events{trace.truncated ? ' · display capped at 1,500 events' : ''}</span>{filtered.length > 8 && <button className="text-btn" onClick={() => setShowAll(v => !v)}>{showAll ? 'Show less' : 'Show all'} <ArrowUpRight size={13}/></button>}</div></section>
        <footer className="page-footer"><div><ShieldCheck size={15}/> Educational sandbox <span>•</span> Only predefined demo programs can be executed.</div><div>Built for Operating Systems · CO-1 to CO-6</div></footer>
      </div>
    </main>
  </div>;
}

createRoot(document.getElementById('root')).render(<React.StrictMode><App/></React.StrictMode>);
